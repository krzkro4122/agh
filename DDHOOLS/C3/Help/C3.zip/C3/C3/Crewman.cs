﻿namespace C3 {
    public class Crewman : Human {
        public Crewman() {
            Weight = 90;
        }
    }
}