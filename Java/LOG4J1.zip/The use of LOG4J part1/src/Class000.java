import org.apache.log4j.Logger;


public class Class000 {

	static final Logger log = Logger.getLogger(Class000.class);

	public static void main(String[] args) {
		
		//BasicConfigurator.configure();
		log.warn("Hello everybody!");
	}
}
